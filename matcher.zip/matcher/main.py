from difflib import get_close_matches
def closeMatches(availdomain, domain): 
     print(get_close_matches(domain, availdomain))
     
domain=input("Enter Domain name")
availdomain=['thegoogle.com', 'good.go', 'google.co.in', 'bing.com'];
closeMatches(availdomain, domain)
